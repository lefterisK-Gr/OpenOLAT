https://code.visualstudio.com/docs/nodejs/nodejs-tutorial
packages:
google-translate
properties-reader
system-sleep